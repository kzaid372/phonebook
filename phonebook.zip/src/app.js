import express from 'express';
import connectDB from './db/conn.js';
import userRoutes from './routes/userRoutes.js'
import contactRoutes from './routes/contactRouotes.js'

const app = express();
const port = process.env.PORT || 1997
app.use(express.json());
connectDB();
app.use("/users", userRoutes);
app.use("/contacts", contactRoutes);
app.listen(port, (err, res) => {
    console.log("success!" + port);
})