import User from '../models/user.js';
import Contact from '../models/contact.js';



const createContact = async (req, res) => {
  try {
    const { uid } = req.params;
    const { id, name, phoneNumber, address } = req.body;
    console.log(uid)
    const user = await User.findOne({ id: uid });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const contact = await Contact.create({ uid, id, name, phoneNumber, address, user: user._id });

    user.contacts.push(contact._id);
    await user.save();

    res.status(201).json(contact);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const getContacts = async (req, res) => {
  try {
    const { uid } = req.params;

    const user = await User.findOne({ id: uid }).populate('contacts');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).json(user.contacts);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const getContactById = async (req, res) => {
  try {
    const { uid, cid } = req.params;

    const user = await User.findOne({ id: uid }).populate('contacts');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const contact = user.contacts.find((contact) => contact.id === cid);
    if (!contact) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.status(200).json(contact);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const updateContactById = async (req, res) => {
  try {
    const { uid, cid } = req.params;


    const user = await User.findOne({ id: uid }).populate('contacts');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const contact = user.contacts.find((contact) => contact.id === cid);
    if (!contact) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    Object.assign(contact, req.body);
    await contact.save();

    res.status(200).json(contact);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const deleteContactById = async (req, res) => {
  try {
    const { uid, cid } = req.params;

    const user = await User.findOne({ id: uid }).populate('contacts');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const contactIndex = user.contacts.findIndex((contact) => contact.id === cid);
    if (contactIndex === -1) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    user.contacts.splice(contactIndex, 1);
    await user.save();

    await Contact.findOneAndDelete({ id: cid });

    res.status(200).json({ message: 'Contact deleted successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export default {
  createContact,
  getContacts,
  getContactById,
  updateContactById,
  deleteContactById
};
