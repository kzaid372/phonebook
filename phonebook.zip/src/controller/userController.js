import User from '../models/user.js';
// import config from '../config.js';
// import  jsonwebtoken  from 'jsonwebtoken';
// import bcrypt from 'bcrypt';


const createUser = async (req, res) => {
  try {
    const { id, firstName, lastName, phoneNumber, password, address, email, age } = req.body;

    const existingUser = await User.findOne({ id });
    if (existingUser) {
      return res.status(400).json({ error: 'User with the same custom ID already exists' });
    }

    const user = await User.create({ id, firstName, lastName, phoneNumber, password, address, email, age });

    res.status(201).json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const getUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const getUserById = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findOne({ id }).populate('contacts');
    if (user) {
      res.status(200).json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// const updateUserById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     console.log(req.body);

//     const user = await User.findOneAndUpdate({ id }, req.body, { new: true });
//     if (user) {
//       res.status(200).json(user);
//     } else {
//       res.status(404).json({ error: 'User not found' });
//     }
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };
// const updateUserById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     console.log(req.body);

//     const user = await User.findOne({ id });

//     if (user) {
//       const updatedUser = await User.findByIdAndUpdate(user._id, req.body, { new: true });
//       res.status(200).json(updatedUser);
//     } else {
//       res.status(404).json({ error: 'User not found' });
//     }
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };

const updateUserById = async (req, res) => {
  try {
    const { id } = req.params;
    console.log(req.body);

    const user = await User.findOne({ id });

    if (user) {
      Object.assign(user, req.body);
      const updatedUser = await user.save();
      res.status(200).json(updatedUser);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};




const deleteUserById = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findOneAndDelete({ id });
    if (user) {
      res.status(200).json({ message: 'User deleted successfully' });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const registerUser = async (req, res) => {
  try {
    const { customId, name, email, age, password } = req.body;

    const existingUser = await User.findOne({ customId });
    if (existingUser) {
      return res.status(400).json({ error: 'User with the same custom ID already exists' });
    }

    const user = await User.create({ customId, name, email, age, password });
    const token = user.generateToken();

    res.status(201).json({ user, token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// User login
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log(email, password);

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    const token = user.generateToken();
    res.status(200).json({ user, token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const logoutUser = async (req, res) => {
  
  res.status(200).json({ message: 'User logged out successfully' });
};


export default {
  createUser,
  getUsers,
  getUserById,
  updateUserById,
  deleteUserById,
  loginUser,
  logoutUser
};
