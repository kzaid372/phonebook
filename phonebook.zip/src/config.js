export default {
    secretKey : 'momin-abuzaid-khan',
    tokenExpiration: '1h'
  };
  