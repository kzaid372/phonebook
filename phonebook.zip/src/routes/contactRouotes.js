import express from 'express';
import contactController from '../controller/contactController.js';
import authenticateUser from '../middlewear/auth.js';


const router = express.Router();


router.post('/:uid', authenticateUser, contactController.createContact);


router.get('/:uid', authenticateUser, contactController.getContacts);


router.get('/:uid/:cid', authenticateUser, contactController.getContactById);

router.put('/:uid/:cid', authenticateUser, contactController.updateContactById);


router.delete('/:uid/:cid', authenticateUser, contactController.deleteContactById);

export default router;
