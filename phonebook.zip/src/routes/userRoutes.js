import express from 'express';
import userController from '../controller/userController.js';
import authenticateUser from '../middlewear/auth.js';


const router = express.Router();


router.post('/register', userController.createUser);


router.post('/login', userController.loginUser);


router.post('/logout', authenticateUser, userController.logoutUser);


router.get('/', authenticateUser, userController.getUsers);


router.get('/:id', authenticateUser, userController.getUserById);


router.put('/:id', authenticateUser, userController.updateUserById);


router.delete('/:id', authenticateUser, userController.deleteUserById);

export default router;
