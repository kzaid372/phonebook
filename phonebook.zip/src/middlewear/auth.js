import jsonwebtoken from 'jsonwebtoken';
import config from '../config.js';

console.log(config);
const authenticateUser = (req, res, next) => {
  const authHeader = req.headers.authorization;

  console.log(authHeader);
  if (!authHeader || !authHeader.startsWith('Bearer')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.split(' ')[1];

  jsonwebtoken.verify(token, config.secretKey, (error, decoded) => {
    if (error) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    req.userId = decoded.userId;
    next();
  });
};

export default authenticateUser;
