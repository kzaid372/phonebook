import mongoose from "mongoose";
import validator from "validator";

const contactSchema = new mongoose.Schema({
    id: {
        type: Number,
        required: true,
        unique: true
    },
    name: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 50
    },
    phoneNumber: {
        type: String,
        required: true,
        unique: true,
        validate: {
            validator: function (value) {
                const phoneRegex = /^[9876]\d{9}$/;
                if (!phoneRegex.test(value)) {
                    throw new Error("Invalid Phone Number");
                }
                return true;
            }
        }
    },
    address: {
        type: String,
        required: true
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }
})
const Contact = mongoose.model('Contact', contactSchema);

export default Contact;