import mongoose from 'mongoose';
import validator from 'validator';
import bcrypt from 'bcrypt';
import jsonwebtoken from 'jsonwebtoken';
import config from '../config.js';

const userSchema = new mongoose.Schema({

    id: {
        type: Number,
        required: true,
        unique: true
    },

    firstName: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 50
    },
    lastName: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 50
    },
    age: {
        type: Number,
        required: true,
        min: 18,
        max: 120
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        validate: {
            validator: function (value) {
                if (!validator.isEmail(value)) {
                    throw new Error("Invalid Email Address");
                }
                return true;
            }
        }
    },
    password: {
        type: String,
        required: true,
        minlength: 6
    },
    phoneNumber: {
        type: String,
        required: true,
        unique: true,
        validate: {
            validator: function (value) {
                const phoneRegex = /^[9876]\d{9}$/;
                if (!phoneRegex.test(value)) {
                    throw new Error("Invalid Phone Number");
                }
                return true;
            }
        }
    },
    address: {
        street: String,
        city: String,
        state: String,
        zipCode: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    contacts: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Contact',
    }]
});


userSchema.pre('save', async function (next) {
    try {
        if (!this.isModified('password')) {
            return next();
        }

        const hashedPassword = await bcrypt.hash(this.password, 10);
        this.password = hashedPassword;
        next();
    } catch (error) {
        next(error);
    }
});


userSchema.methods.generateToken = function () {
    const token = jsonwebtoken.sign({ userId: this._id }, config.secretKey, { expiresIn: config.tokenExpiration });
    return token;
};


userSchema.methods.comparePassword = async function (password) {
    const isMatch = await bcrypt.compare(password, this.password);
    return isMatch;
};

const User = mongoose.model("User", userSchema);

export default User;
